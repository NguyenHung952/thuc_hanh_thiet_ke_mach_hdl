module bai2 (
    input CLOCK_50,
    input [1:0] SW,     // SW[0]=reset, SW[1]=S
    output reg [7:0] LEDR
);

//================ CLOCK 500ms =================
integer count;
reg clk_500ms = 0;

always @(posedge CLOCK_50) begin
    count = count + 1;
    if (count == 25000000) begin
        clk_500ms = ~clk_500ms;
        count = 0;
    end
end

//================ FSM =================
parameter s0=3'd0, s1=3'd1, s2=3'd2, s3=3'd3,
          s4=3'd4, s5=3'd5, s6=3'd6, s7=3'd7;

reg [2:0] current_state, next_state;

//=========== NEXT STATE ===========
always @(*) begin
    case(current_state)
        s0: next_state = s1;
        s1: next_state = s2;
        s2: next_state = s3;
        s3: next_state = s4;
        s4: next_state = s5;
        s5: next_state = s6;
        s6: next_state = s7;
        s7: next_state = s0;
        default: next_state = s0;
    endcase
end

//=========== STATE REGISTER ===========
always @(posedge clk_500ms or posedge SW[0]) begin
    if (SW[0]) current_state <= s0;
    else current_state <= next_state;
end

//=========== OUTPUT ===========
always @(*) begin
    if (SW[0]) begin
        LEDR = 8'b00000000;
    end else begin
        case(SW[1])  // chọn mode

        //===== S = 0 : sáng dần phải -> trái =====
        1'b0: begin
            case(current_state)
                s0: LEDR = 8'b00000001;
                s1: LEDR = 8'b00000011;
                s2: LEDR = 8'b00000111;
                s3: LEDR = 8'b00001111;
                s4: LEDR = 8'b00011111;
                s5: LEDR = 8'b00111111;
                s6: LEDR = 8'b01111111;
                s7: LEDR = 8'b11111111;
            endcase
        end

        //===== S = 1 : chạy đuổi trái -> phải =====
        1'b1: begin
            case(current_state)
                s0: LEDR = 8'b10000000;
                s1: LEDR = 8'b01000000;
                s2: LEDR = 8'b00100000;
                s3: LEDR = 8'b00010000;
                s4: LEDR = 8'b00001000;
                s5: LEDR = 8'b00000100;
                s6: LEDR = 8'b00000010;
                s7: LEDR = 8'b00000001;
            endcase
        end

        endcase
    end
end

endmodule