module bai1 (
    input CLOCK_50,
    input [0:0] SW,          // reset active high
    output reg [6:0] HEX0, HEX1, HEX2, HEX3
);

//================ CLOCK ENABLE 500ms =================
reg [25:0] count = 0;
reg tick_500ms = 0;

always @(posedge CLOCK_50) begin
    if (count == 25_000_000 - 1) begin
        count <= 0;
        tick_500ms <= 1;   // xung 1 chu kỳ
    end else begin
        count <= count + 1;
        tick_500ms <= 0;
    end
end

//================ FSM =================
parameter S0=3'd0, S1=3'd1, S2=3'd2, S3=3'd3, 
          S4=3'd4, S5=3'd5, S6=3'd6;

reg [2:0] current_state, next_state;

//=========== NEXT STATE ===========
always @(*) begin
    case(current_state)
        S0: next_state = S1;
        S1: next_state = S2;
        S2: next_state = S3;
        S3: next_state = S4;
        S4: next_state = S5;
        S5: next_state = S6;
        S6: next_state = S0;
        default: next_state = S0;
    endcase
end

//=========== STATE REGISTER (ĐÚNG CHUẨN ĐỀ) ===========
always @(posedge CLOCK_50 or posedge SW[0]) begin
    if (SW[0])
        current_state <= S0;
    else if (tick_500ms)     // chạy mỗi 500ms
        current_state <= next_state;
end

//================ OUTPUT =================
always @(*) begin
    // reset → tắt hết
    if (SW[0]) begin
        HEX3 = OFF;
        HEX2 = OFF;
        HEX1 = OFF;
        HEX0 = OFF;
    end
    else begin
        HEX3 = OFF;
        HEX2 = OFF;
        HEX1 = OFF;
        HEX0 = OFF;

        case(current_state)

            S0: begin
                HEX2 = P;
                HEX1 = E;
                HEX0 = P;
            end

            S1: begin
                HEX3 = P;
                HEX2 = E;
                HEX1 = P;
                HEX0 = S;
            end

            S2: begin
                HEX3 = E;
                HEX2 = P;
                HEX1 = S;
                HEX0 = I;
            end

            S3: begin
                HEX3 = P;
                HEX2 = S;
                HEX1 = I;
            end

            S4: begin
                HEX3 = S;
                HEX2 = I;
            end

            S5: begin
                HEX3 = I;
            end

            S6: begin
                // pause 500ms (màn hình trống)
                HEX3 = OFF;
                HEX2 = OFF;
                HEX1 = OFF;
                HEX0 = OFF;
            end

        endcase
    end
end

//================ FONT =================
localparam [6:0]
    OFF = 7'b1111111,
    P   = 7'b0001100,
    E   = 7'b0000110,
    S   = 7'b0010010,
    I   = 7'b1111001;

endmodule