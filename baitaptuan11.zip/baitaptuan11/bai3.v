// BTAP3 - He thong dieu khien den giao thong 24 TRANG THAI
module bai3 ( SW, LEDR, CLOCK_50, HEX7, HEX6, HEX5, HEX4);
    input [0:0] SW;     
    input CLOCK_50;
    output reg [5:0] LEDR; 
    output reg [6:0] HEX7, HEX6, HEX5, HEX4;

    // Khai bao 24 trang thai tu S0 den S23
    reg [4:0] current_state, next_state;
    parameter S0=0, S1=1, S2=2, S3=3, S4=4, S5=5, S6=6, S7=7, S8=8, S9=9,
              S10=10, S11=11, S12=12, S13=13, S14=14, S15=15, S16=16, S17=17, 
              S18=18, S19=19, S20=20, S21=21, S22=22, S23=23;

    reg [25:0] q; 
    wire tick_1s = (q == 50000000); 

    // Bo chia xung 1s
    always @(posedge CLOCK_50) begin
        if (q >= 50000000 || SW[0]) q <= 0;
        else q <= q + 1;
    end

    // Cap nhat trang thai moi giay
    always @(posedge CLOCK_50 or posedge SW[0]) begin
        if (SW[0]) current_state <= S0;
        else if (tick_1s) current_state <= next_state;
    end

    // Khối xác định trạng thái kế tiếp (CHAY TU S0 DEN S23)
    always @(*) begin
        case (current_state)
            S0:  next_state = S1;  S1:  next_state = S2;  S2:  next_state = S3;
            S3:  next_state = S4;  S4:  next_state = S5;  S5:  next_state = S6;
            S6:  next_state = S7;  S7:  next_state = S8;  S8:  next_state = S9;
            S9:  next_state = S10; S10: next_state = S11; S11: next_state = S12;
            S12: next_state = S13; S13: next_state = S14; S14: next_state = S15;
            S15: next_state = S16; S16: next_state = S17; S17: next_state = S18;
            S18: next_state = S19; S19: next_state = S20; S20: next_state = S21;
            S21: next_state = S22; S22: next_state = S23; S23: next_state = S0;
            default: next_state = S0;
        endcase
    end

    // Khối điều khiển LED và Giá trị đếm ngược
    reg [3:0] dA, dB;
    always @(*) begin
        case (current_state)
            // PHA 1: Trụ A Xanh (10s), Trụ B Đỏ (12s)
            S0: begin dA=10; dB=12; LEDR=6'b100001; end
            S1: begin dA=9;  dB=11; LEDR=6'b100001; end
            S2: begin dA=8;  dB=10; LEDR=6'b100001; end
            S3: begin dA=7;  dB=9;  LEDR=6'b100001; end
            S4: begin dA=6;  dB=8;  LEDR=6'b100001; end
            S5: begin dA=5;  dB=7;  LEDR=6'b100001; end
            S6: begin dA=4;  dB=6;  LEDR=6'b
    100001; end
            S7: begin dA=3;  dB=5;  LEDR=6'b100001; end
            S8: begin dA=2;  dB=4;  LEDR=6'b100001; end
            S9: begin dA=1;  dB=3;  LEDR=6'b100001; end
            
            // PHA 2: Trụ A Vàng (2s), Trụ B Đỏ (2s)
            S10: begin dA=2; dB=2; LEDR=6'b100010; end
            S11: begin dA=1; dB=1; LEDR=6'b100010; end
            
            // PHA 3: Trụ A Đỏ (12s), Trụ B Xanh (10s)
            S12: begin dA=12; dB=10; LEDR=6'b001100; end
            S13: begin dA=11; dB=9;  LEDR=6'b001100; end
            S14: begin dA=10; dB=8;  LEDR=6'b001100; end
				S15: begin dA=9;  dB=7;  LEDR=6'b001100; end
    S16: begin dA=8;  dB=6;  LEDR=6'b001100; end
            S17: begin dA=7;  dB=5;  LEDR=6'b001100; end
            S18: begin dA=6;  dB=4;  LEDR=6'b001100; end
            S19: begin dA=5;  dB=3;  LEDR=6'b001100; end
            S20: begin dA=4;  dB=2;  LEDR=6'b001100; end
            S21: begin dA=3;  dB=1;  LEDR=6'b001100; end
            
            // PHA 4: Trụ A Đỏ (2s), Trụ B Vàng (2s)
            S22: begin dA=2; dB=2; LEDR=6'b010100; end
            S23: begin dA=1; dB=1; LEDR=6'b010100; end
            
            default: begin dA=0; dB=0; LEDR=6'b000000; end
        endcase
        
        // Hien thi len HEX
        HEX7 = decode(dA / 10); HEX6 = decode(dA % 10);
        HEX5 = decode(dB / 10); HEX4 = decode(dB % 10);
    end

    // Ham giai ma LED 7 doan
    function [6:0] decode(input [3:0] v);
        case (v)
            0: decode=7'b1000000; 1: decode=7'b1111001; 2: decode=7'b0100100;
            3: decode=7'b0110000; 4: decode=7'b0011001; 5: decode=7'b0010010;
            6: decode=7'b0000010; 7: decode=7'b1111000; 8: decode=7'b0000000;
            9: decode=7'b0010000; default: decode=7'b1111111;
        endcase
    endfunction
endmodule