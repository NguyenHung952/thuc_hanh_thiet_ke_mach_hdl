module bai4 (
    input CLOCK_50,
    input [0:0] SW,        // reset
    output reg [6:0] HEX7, HEX6, HEX5, HEX4,
    output reg [6:0] HEX3, HEX2, HEX1, HEX0,
    output reg [17:0] LEDR
);

//================ CLOCK =================
// 1Hz cho blink
integer c1;
reg clk_1s = 0;

always @(posedge CLOCK_50) begin
    c1 = c1 + 1;
    if (c1 == 25000000) begin
        clk_1s = ~clk_1s;
        c1 = 0;
    end
end

// 300ms cho FSM
integer c2;
reg clk_300ms = 0;

always @(posedge CLOCK_50) begin
    c2 = c2 + 1;
    if (c2 == 15000000) begin
        clk_300ms = ~clk_300ms;
        c2 = 0;
    end
end

//================ FSM =================
parameter s0=5'd0, s1=5'd1, s2=5'd2, s3=5'd3, s4=5'd4,
          s5=5'd5, s6=5'd6, s7=5'd7, s8=5'd8;

reg [4:0] state;

// state register
always @(posedge clk_300ms or posedge SW[0]) begin
    if (SW[0]) state <= s0;
    else begin
        if (state == s8) state <= s0;
        else state <= state + 1;
    end
end

//================ LEDR hiệu ứng =================
always @(*) begin
    if (SW[0]) LEDR = 18'b0;
    else begin
        case(state)
        s0: LEDR = 18'b000000000000000000;
        s1: LEDR = 18'b100000000000000001;
        s2: LEDR = 18'b110000000000000011;
        s3: LEDR = 18'b111000000000000111;
        s4: LEDR = 18'b111100000000001111;
        s5: LEDR = 18'b111110000000011111;
        s6: LEDR = 18'b111111000000111111;
        s7: LEDR = 18'b111111100001111111;
        s8: LEDR = 18'b111111111111111111;
        endcase
    end
end

//================ HIỂN THỊ HEX =================
wire blink = clk_1s;

always @(*) begin
    if (SW[0] || !blink) begin
        HEX7 = 7'b1111111;
        HEX6 = 7'b1111111;
        HEX5 = 7'b1111111;
        HEX4 = 7'b1111111;
        HEX3 = 7'b1111111;
        HEX2 = 7'b1111111;
        HEX1 = 7'b1111111;
        HEX0 = 7'b1111111;
    end else begin
        HEX7 = D;
        HEX6 = E;
        HEX5 = TWO;
        HEX4 = DASH;
        HEX3 = F;
        HEX2 = P;
        HEX1 = G;
        HEX0 = A;
    end
end

//================ FONT =================
// anode chung (0 sáng)

wire [6:0] D    = 7'b0100001;
wire [6:0] E    = 7'b0000110;
wire [6:0] TWO  = 7'b0100100;
wire [6:0] DASH = 7'b0111111;
wire [6:0] F    = 7'b0001110;
wire [6:0] P    = 7'b0001100;
wire [6:0] G    = 7'b0010000;
wire [6:0] A    = 7'b0001000;

endmodule