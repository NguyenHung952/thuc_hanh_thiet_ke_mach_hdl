module bai5 (
    input CLOCK_50,
    input [1:0] SW,   // SW[0]=reset, SW[1]=C
    output [1:0] LEDR // LEDR[1]=a, LEDR[0]=b
);

wire C = SW[1];
wire reset = SW[0];

reg Q1, Q0;
reg next_Q1, next_Q0;

//================ NEXT STATE =================
always @(*) begin
    next_Q1 = Q0;
    next_Q0 = C ^ Q1;
end

//================ STATE REGISTER =================
always @(posedge CLOCK_50 or posedge reset) begin
    if (reset) begin
        Q1 <= 0;
        Q0 <= 0;
    end else begin
        Q1 <= next_Q1;
        Q0 <= next_Q0;
    end
end

//================ OUTPUT (MOORE) =================
assign LEDR[1] = Q1 & Q0;      // a
assign LEDR[0] = Q1 & ~Q0;     // b

endmodule