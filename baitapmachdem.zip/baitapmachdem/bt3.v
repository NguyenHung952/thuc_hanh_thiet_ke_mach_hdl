module bt3 (SW,KEY,LEDR);
input [2:0]SW;
input [3:0]KEY;
output [4:1]LEDR;
wire q1,q2,q3;
wire a1,a2,a3;

FF_T t1 (KEY[2],SW[0],SW[2],LEDR[1]);
and(a1,SW[0],LEDR[1]);
FF_T t2 (KEY[2],a1,SW[2],LEDR[2]);
and(a2,a1,LEDR[2]);
FF_T t3 (KEY[2],a2,SW[2],LEDR[3]);
and(a3,a2,LEDR[3]);
FF_T t4 (KEY[2],a3,SW[2],LEDR[4]);

endmodule

module FF_T (ck, t, rs, q);
input ck, t, rs;
output q;
reg q;
always @ (posedge ck)
begin
 if (rs == 1'b0) 
 q <= 0;
 else 
  if (t == 1'b0)
   q <= q;
  else
   q <= !q;
end
endmodule