module counter(clk, reset, count);

input clk, reset;
output reg [4:0] count;

always @(posedge clk or posedge reset) begin
    if(reset)
        count <= 0;
    else if(count == 27)
        count <= 0;
    else
        count <= count + 1;
end

endmodule
module display(count, HEX1, HEX0);

input [4:0] count;
output reg [6:0] HEX1;
output reg [6:0] HEX0;

reg [3:0] tens;
reg [3:0] ones;

always @(*) begin

    tens = count / 10;
    ones = count % 10;

    case(tens)
        0: HEX1 = 7'b1000000;
        1: HEX1 = 7'b1111001;
        2: HEX1 = 7'b0100100;
        default: HEX1 = 7'b1111111;
    endcase

    case(ones)
        0: HEX0 = 7'b1000000;
        1: HEX0 = 7'b1111001;
        2: HEX0 = 7'b0100100;
        3: HEX0 = 7'b0110000;
        4: HEX0 = 7'b0011001;
        5: HEX0 = 7'b0010010;
        6: HEX0 = 7'b0000010;
        7: HEX0 = 7'b1111000;
        8: HEX0 = 7'b0000000;
		  9: HEX0 = 7'b0010000;
		  
        default: HEX0 = 7'b1111111;
    endcase

end

endmodule
module bt6(SW,KEY, HEX1, HEX0);

input [1:0] SW;
input [1:0] KEY;
output [6:0] HEX1;
output [6:0] HEX0;

wire [4:0] count;

counter C1(KEY[1], SW[1], count);
display D1(count, HEX1, HEX0);

endmodule


					
					