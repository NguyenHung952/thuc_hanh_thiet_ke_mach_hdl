module bt5(SW, LEDR,KEY);

input [16:16] SW;
input [2:0]KEY;
output reg [17:14] LEDR;

always @ (posedge KEY[2])
begin
    if(SW[16] == 1'b0)
	     LEDR <= 4'b0000;
    else if (LEDR == 4'b0000)
        LEDR <= 4'b1001;
    else
        LEDR <= LEDR - 1'b1;
end

endmodule