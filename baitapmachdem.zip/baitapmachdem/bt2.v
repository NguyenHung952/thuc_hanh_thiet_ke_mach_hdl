module bt2(SW, LEDR);
input [2:0] SW;
output reg [2:0] LEDR;   // 👈 mở rộng tới bit 2

always @(negedge SW[0] or posedge SW[1])
begin
    if (SW[1] == 1'b1)
        LEDR[2] <= 1'b0;
    else if (SW[2] == 1'b1)
        LEDR[2] <= ~LEDR[2];   // T = 1 → đảo
    else
        LEDR[2] <= LEDR[2];    // T = 0 → giữ
end

endmodule