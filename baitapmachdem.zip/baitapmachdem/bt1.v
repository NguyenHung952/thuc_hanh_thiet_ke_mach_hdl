module bt1 (SW, LEDR);
input [2:0] SW;
output [1:1] LEDR;
reg q;
always @(posedge SW[0])      
begin
    if (SW[1] == 1'b0)       
        q <= 1'b0;
    else
        q <= SW[2];          
end
assign LEDR[1] = q;          
endmodule