module bt4(
    input [17:0] SW,
    input [3:0] KEY,
    output [4:1] LEDR
);

counter_mod14 u1(
    .clk(KEY[2]),    
    .rs_n(SW[16]),   
    .led(LEDR[4:1])
);

endmodule


module counter_mod14(clk, rs_n, led);
    input wire clk;
    input wire rs_n;
    output reg [3:0] led;

always @(posedge clk or negedge rs_n)
begin
    if (!rs_n)
        led <= 4'd0;
    else if (led == 4'd13)
        led <= 4'd0;
    else
        led <= led + 1'b1;
end

endmodule