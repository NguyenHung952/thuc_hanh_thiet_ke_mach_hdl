module bai3 (KEY,SW,HEX6,HEX7);
	input [2:2] KEY;    
   input [1:1] SW; 
   output [7:0] HEX6;  
   output [7:0] HEX7;  

   wire [7:0] Q;
   Counter machdem (KEY,SW,Q);

   giaima donvi ((Q[3:0]),(HEX6));

   giaima chuc ((Q[7:4]),(HEX7));

endmodule

module Counter (KEY, SW, LEDR);
    input [2:2] KEY;
    input [1:1] SW;
    output reg [7:0] LEDR;

    always @ (posedge KEY[2] or negedge SW[1])
    begin
        if (SW[1] == 0) 
        begin
            LEDR <= 8'b0;
        end
        else 
        begin
				LEDR[7:4] <= 4'b1000;
				LEDR[3:0] <= 4'b0010;
			end
		else
			begin
					LEDR[7:4] <= LEDR[7:4] + 1'b1;
				end
				if (LEDR[7:4] == 4'b0010 && LEDR[3:0] == 4'b0100)
				begin
					LEDR[7:4] <= 4'b0000;
					LEDR[3:0] <= 4'b0000;
				end
        end
    end
endmodule

module giaima (bcd, hex);
    input [3:0] bcd;
    output reg [6:0] hex;
    always @(*) begin
        case (bcd)
            4'h0: hex = 7'b1000000; // 0
            4'h1: hex = 7'b1111001; // 1
            4'h2: hex = 7'b0100100; // 2
            4'h3: hex = 7'b0110000; // 3
            4'h4: hex = 7'b0011001; // 4
            4'h5: hex = 7'b0010010; // 5
            4'h6: hex = 7'b0000010; // 6
            4'h7: hex = 7'b1111000; // 7
            4'h8: hex = 7'b0000000; // 8
            4'h9: hex = 7'b0010000; // 9
            default: hex = 7'b1111111; // Tắt
        endcase
    end
endmodule