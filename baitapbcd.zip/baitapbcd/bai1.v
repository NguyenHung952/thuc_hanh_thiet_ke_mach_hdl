module bai1 (KEY, SW, LEDR);

input [2:0] KEY;
input [1:1] SW;
output [7:0] LEDR;

reg [3:0] dv, ch;
reg [7:0] LEDR;

always @(posedge KEY[2] or posedge SW[1])
begin
    if (SW[1] == 1'b1)
    begin
        dv <= 0;
        ch <= 0;
    end
    else
    begin
        // nếu đang là 29 → next = 30 → reset luôn
        if (ch == 2 && dv == 9)
        begin
            dv <= 0;
            ch <= 3;
        end
        // nếu đang là 30 → reset về 00
        else if (ch == 3 && dv == 0)
        begin
            dv <= 0;
            ch <= 0;
        end
        else if (dv == 9)
        begin
            dv <= 0;
            ch <= ch + 1;
        end
        else
            dv <= dv + 1;
    end
end

// hiển thị
always @(*)
begin
    LEDR[3:0] = dv;
    LEDR[7:4] = ch;
end

endmodule