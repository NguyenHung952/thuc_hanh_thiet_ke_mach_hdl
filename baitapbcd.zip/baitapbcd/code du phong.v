CODE DU PHONG

module bai1 (KEY, SW, LEDR);

input [2:0] KEY;
input [1:1] SW;
output [7:0] LEDR;

reg [3:0] dv, ch;
reg [7:0] LEDR;

always @(posedge KEY[2] or posedge SW[1])
begin
    if (SW[1] == 1'b1)
    begin
        dv <= 0;
        ch <= 0;
    end
    else
    begin
        // nếu đang là 29 → next = 30 → reset luôn
        if (ch == 2 && dv == 9)
        begin
            dv <= 0;
            ch <= 3;
        end
        // nếu đang là 30 → reset về 00
        else if (ch == 3 && dv == 0)
        begin
            dv <= 0;
            ch <= 0;
        end
        else if (dv == 9)
        begin
            dv <= 0;
            ch <= ch + 1;
        end
        else
            dv <= dv + 1;
    end
end

// hiển thị
always @(*)
begin
    LEDR[3:0] = dv;
    LEDR[7:4] = ch;
end

endmodule









module bai2 (KEY, LEDR, SW);

input [2:0] KEY;
input [1:1] SW;
output [7:0] LEDR;

reg [3:0] dv, ch;
reg [7:0] LEDR;

// ck cạnh xuống, reset đồng bộ mức thấp
always @(negedge KEY[2])
begin
    if (SW[1] == 1'b0)
    begin
        dv <= 2;
        ch <= 1;   // bắt đầu từ 12
    end
    else
    begin
        // nếu đang là 00 → quay lại 12
        if (ch == 0 && dv == 0)
        begin
            dv <= 2;
            ch <= 1;
        end
        // nếu dv = 0 → mượn từ chục
        else if (dv == 0)
        begin
            dv <= 9;
            ch <= ch - 1;
        end
        else
            dv <= dv - 1;
    end
end

// hiển thị
always @(*)
begin
    LEDR[3:0] = dv;
    LEDR[7:4] = ch;
end

endmodule










module bai3 (KEY, HEX6, HEX7, SW);

input [2:0] KEY;
input	[1:1]	SW;
output [6:0] HEX6, HEX7;

reg [3:0] dv, ch;

// ck cạnh lên, reset không đồng bộ mức thấp
always @(posedge KEY[2] or negedge SW[1])
begin
    if (SW[1] == 1'b0)
    begin
        dv <= 0;
        ch <= 0;
    end
    else
    begin
        // nếu đang là 24 → reset về 00
        if (ch == 2 && dv == 4)
        begin
            dv <= 0;
            ch <= 0;
        end
        // nếu dv = 9 → tăng chục
        else if (dv == 9)
        begin
            dv <= 0;
            ch <= ch + 1;
        end
        else
            dv <= dv + 1;
    end
end

// hiển thị
bcd7seg h0 (dv, HEX6); // đơn vị
bcd7seg h1 (ch, HEX7); // chục

endmodule


















module bai4 (KEY, HEX5, HEX6, HEX7,SW);

input [2:0] KEY;
input [1:1] SW;
output reg [6:0] HEX5, HEX6, HEX7;

reg [3:0] dv, ch, tr;

// ===== COUNTER =====
always @(posedge KEY[2])
begin
    if (SW[1] == 1'b1)  // reset đồng bộ mức cao
    begin
        dv <= 1;
        ch <= 0;
        tr <= 0;
    end
    else
    begin
        // ===== TRẠNG THÁI BIÊN: 099 → 001 =====
        if (tr == 0 && ch == 9 && dv == 9)
        begin
            dv <= 1;
            ch <= 0;
            tr <= 0;
        end
        else
        begin
            // ===== TĂNG +2 (GIỮ SỐ LẺ) =====
            if (dv == 9)
            begin
                dv <= 1;         // 9 + 2 = 11 → dv=1
                ch <= ch + 1;
            end
            else if (dv == 8)
            begin
                dv <= 0;         // 8 + 2 = 10
                ch <= ch + 1;
            end
            else
                dv <= dv + 2;

            // ===== XỬ LÝ CHỤC → TRĂM =====
            if (ch == 9 && dv >= 8)
            begin
                ch <= 0;
                tr <= tr + 1;
            end
        end

        // ===== CHẶN >=100 =====
        if (tr == 1)
        begin
            dv <= 1;
            ch <= 0;
            tr <= 0;
        end
    end
end

// ===== HEX5 (đơn vị) =====
always @(*)
begin
    case(dv)
        0: HEX5 = 7'b1000000;
        1: HEX5 = 7'b1111001;
        2: HEX5 = 7'b0100100;
        3: HEX5 = 7'b0110000;
        4: HEX5 = 7'b0011001;
        5: HEX5 = 7'b0010010;
        6: HEX5 = 7'b0000010;
        7: HEX5 = 7'b1111000;
        8: HEX5 = 7'b0000000;
        9: HEX5 = 7'b0010000;
        default: HEX5 = 7'b1111111;
    endcase
end

// ===== HEX6 (chục) =====
always @(*)
begin
    case(ch)
        0: HEX6 = 7'b1000000;
        1: HEX6 = 7'b1111001;
        2: HEX6 = 7'b0100100;
        3: HEX6 = 7'b0110000;
        4: HEX6 = 7'b0011001;
        5: HEX6 = 7'b0010010;
        6: HEX6 = 7'b0000010;
        7: HEX6 = 7'b1111000;
        8: HEX6 = 7'b0000000;
        9: HEX6 = 7'b0010000;
        default: HEX6 = 7'b1111111;
    endcase
end

// ===== HEX7 (trăm) =====
always @(*)
begin
    case(tr)
        0: HEX7 = 7'b1000000;
        1: HEX7 = 7'b1111001;
        default: HEX7 = 7'b1111111;
    endcase
end

endmodule