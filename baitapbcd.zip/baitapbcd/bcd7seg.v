module bcd7seg (bcd, led);

input [3:0] bcd;
output [6:0] led;
reg [6:0] led;

always @(bcd)
begin
    case(bcd)
        0: led = 7'b1000000;
        1: led = 7'b1111001;
        2: led = 7'b0100100;
        3: led = 7'b0110000;
        4: led = 7'b0011001;
        5: led = 7'b0010010;
        6: led = 7'b0000010;
        7: led = 7'b1111000;
        8: led = 7'b0000000;
        9: led = 7'b0010000;
        default: led = 7'b1111111;
    endcase
end

endmodule