module bai5 (KEY, HEX0, HEX1, HEX2);

input [2:0] KEY;
output [6:0] HEX0, HEX1, HEX2;

reg [3:0] dv, ch, tr;

always @(posedge KEY[2] or negedge KEY[0])
begin
    if (KEY[0] == 1'b0)
    begin
        dv <= 0;
        ch <= 5;
        tr <= 1;
    end
    else
    begin
        if (dv == 0)
        begin
            dv <= 9;

            if (ch == 0)
            begin
                ch <= 9;
                tr <= tr - 1;
            end
            else
                ch <= ch - 1;
        end
        else
            dv <= dv - 1;

        if (tr == 1 && ch == 0 && dv == 0)
        begin
            dv <= 0;
            ch <= 5;
            tr <= 1;
        end
    end
end

bcd7seg h0 (dv, HEX0);
bcd7seg h1 (ch, HEX1);
bcd7seg h2 (tr, HEX2);

endmodule