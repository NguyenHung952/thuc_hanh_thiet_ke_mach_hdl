module bai2 (KEY, LEDR, SW);

input [2:0] KEY;
input [1:1] SW;
output [7:0] LEDR;

reg [3:0] dv, ch;
reg [7:0] LEDR;

// ck cạnh xuống, reset đồng bộ mức thấp
always @(negedge KEY[2])
begin
    if (SW[1] == 1'b0)
    begin
        dv <= 2;
        ch <= 1;   // bắt đầu từ 12
    end
    else
    begin
        // nếu đang là 00 → quay lại 12
        if (ch == 0 && dv == 0)
        begin
            dv <= 2;
            ch <= 1;
        end
        // nếu dv = 0 → mượn từ chục
        else if (dv == 0)
        begin
            dv <= 9;
            ch <= ch - 1;
        end
        else
            dv <= dv - 1;
    end
end

// hiển thị
always @(*)
begin
    LEDR[3:0] = dv;
    LEDR[7:4] = ch;
end

endmodule