module bai4 (KEY, HEX5, HEX6, HEX7,SW);

input [2:0] KEY;
input [1:1] SW;
output reg [6:0] HEX5, HEX6, HEX7;

reg [3:0] dv, ch, tr;

// ===== COUNTER =====
always @(posedge KEY[2])
begin
    if (SW[1] == 1'b1)  // reset đồng bộ mức cao
    begin
        dv <= 1;
        ch <= 0;
        tr <= 0;
    end
    else
    begin
        // ===== TRẠNG THÁI BIÊN: 099 → 001 =====
        if (tr == 0 && ch == 9 && dv == 9)
        begin
            dv <= 1;
            ch <= 0;
            tr <= 0;
        end
        else
        begin
            // ===== TĂNG +2 (GIỮ SỐ LẺ) =====
            if (dv == 9)
            begin
                dv <= 1;         // 9 + 2 = 11 → dv=1
                ch <= ch + 1;
            end
            else if (dv == 8)
            begin
                dv <= 0;         // 8 + 2 = 10
                ch <= ch + 1;
            end
            else
                dv <= dv + 2;

            // ===== XỬ LÝ CHỤC → TRĂM =====
            if (ch == 9 && dv >= 8)
            begin
                ch <= 0;
                tr <= tr + 1;
            end
        end

        // ===== CHẶN >=100 =====
        if (tr == 1)
        begin
            dv <= 1;
            ch <= 0;
            tr <= 0;
        end
    end
end

// ===== HEX5 (đơn vị) =====
always @(*)
begin
    case(dv)
        0: HEX5 = 7'b1000000;
        1: HEX5 = 7'b1111001;
        2: HEX5 = 7'b0100100;
        3: HEX5 = 7'b0110000;
        4: HEX5 = 7'b0011001;
        5: HEX5 = 7'b0010010;
        6: HEX5 = 7'b0000010;
        7: HEX5 = 7'b1111000;
        8: HEX5 = 7'b0000000;
        9: HEX5 = 7'b0010000;
        default: HEX5 = 7'b1111111;
    endcase
end

// ===== HEX6 (chục) =====
always @(*)
begin
    case(ch)
        0: HEX6 = 7'b1000000;
        1: HEX6 = 7'b1111001;
        2: HEX6 = 7'b0100100;
        3: HEX6 = 7'b0110000;
        4: HEX6 = 7'b0011001;
        5: HEX6 = 7'b0010010;
        6: HEX6 = 7'b0000010;
        7: HEX6 = 7'b1111000;
        8: HEX6 = 7'b0000000;
        9: HEX6 = 7'b0010000;
        default: HEX6 = 7'b1111111;
    endcase
end

// ===== HEX7 (trăm) =====
always @(*)
begin
    case(tr)
        0: HEX7 = 7'b1000000;
        1: HEX7 = 7'b1111001;
        default: HEX7 = 7'b1111111;
    endcase
end

endmodule