module baitap1(
    input  [3:0] SW,   // A B C D
    output [6:0] HEX0
);

wire A = SW[3];
wire B = SW[2];
wire C = SW[1];
wire D = SW[0];

wire a, b, c, d, e, f, g;

// ===== LOGIC TỐI ƯU =====
assign a = (~B & ~D) | (C) | (A & B) | (~A & B & D);

assign b = (~B) | (~C & ~D) | (C & D);

assign c = (~C) | D | B;

assign d = (~B & ~D) | (~A & B & ~C) | (B & C & D) | (~A & ~B & C) | (A & ~B & ~C & D);

assign e = (~B & ~D) | (~A & D);

assign f = (~C & ~D) | (~A & B & ~C) | (~A & C & D) | (A & ~B & ~C);

assign g = (~B & C) | (~A & B & ~C) | (B & ~C & D) | (A & ~B & ~C);

// ===== ANODE CHUNG =====
assign HEX0 = {~g, ~f, ~e, ~d, ~c, ~b, ~a};

endmodule