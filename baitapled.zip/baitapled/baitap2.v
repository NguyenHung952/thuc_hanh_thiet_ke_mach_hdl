module baitap2(
    input  [15:0] SW,
    output [6:0] HEX0,
    output [6:0] HEX1,
    output [6:0] HEX2,
    output [6:0] HEX3
);

wire [6:0] seg0, seg1, seg2, seg3;

// 4 decoder
seg7_decoder U0 (.bcd(SW[3:0]),   .seg(seg0));
seg7_decoder U1 (.bcd(SW[7:4]),   .seg(seg1));
seg7_decoder U2 (.bcd(SW[11:8]),  .seg(seg2));
seg7_decoder U3 (.bcd(SW[15:12]), .seg(seg3));

// BCD > 9 thì OFF (1111111)
assign HEX0 = (SW[3:0]   <= 4'd9) ? seg0 : 7'b1111111;
assign HEX1 = (SW[7:4]   <= 4'd9) ? seg1 : 7'b1111111;
assign HEX2 = (SW[11:8]  <= 4'd9) ? seg2 : 7'b1111111;
assign HEX3 = (SW[15:12] <= 4'd9) ? seg3 : 7'b1111111;

endmodule