module seg7_char(
    input  [2:0] data,
    output reg [6:0] seg
);

// active LOW (0 = sáng)
always @(*) begin
    case(data)
        3'b000: seg = 7'b0001110; // F
        3'b001: seg = 7'b0001100; // P
        3'b010: seg = 7'b0010000; // G ✅ sửa
        3'b011: seg = 7'b0001000; // A
        3'b100: seg = 7'b0111111; // -
        3'b101: seg = 7'b0100001; // d (D dạng thường) ✅ sửa
        3'b110: seg = 7'b0000110; // E
			3'b111: seg = 7'b0100100; // 2 ✅
        default: seg = 7'b1111111;
    endcase
end

endmodule