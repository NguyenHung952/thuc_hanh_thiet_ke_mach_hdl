
QSAzmodule baitap3(
    input  [17:0] SW,
    output reg [6:0] HEX0,
    output reg [6:0] HEX1,
    output reg [6:0] HEX2,
    output reg [6:0] HEX3,
    output reg [6:0] HEX4,
    output reg [6:0] HEX5,
    output reg [6:0] HEX6,
    output reg [6:0] HEX7
);

// ===== Mã 7 đoạn (active LOW) =====
parameter H = 7'b0001001;
parameter E = 7'b0000110;
parameter L = 7'b1000111;
parameter O = 7'b1000000;
parameter OFF = 7'b1111111;

always @(*) begin
    // default: tắt hết
    HEX0 = OFF; HEX1 = OFF; HEX2 = OFF; HEX3 = OFF;
    HEX4 = OFF; HEX5 = OFF; HEX6 = OFF; HEX7 = OFF;

    case(SW[17:15])

        // 000: --- HELLO
        3'b000: begin
            HEX4 = H; HEX3 = E; HEX2 = L; HEX1 = L; HEX0 = O;
        end

        // 001: -- HELLO-
        3'b001: begin
            HEX5 = H; HEX4 = E; HEX3 = L; HEX2 = L; HEX1 = O;
        end

        // 010: - HELLO--
        3'b010: begin
            HEX6 = H; HEX5 = E; HEX4 = L; HEX3 = L; HEX2 = O;
        end

        // 011:  HELLO---
        3'b011: begin
            HEX7 = H; HEX6 = E; HEX5 = L; HEX4 = L; HEX3 = O;
        end

        // 100: ELLO---H
        3'b100: begin
            HEX7 = E; HEX6 = L; HEX5 = L; HEX4 = O;
            HEX0 = H;
        end

        // 101: LLO---HE
        3'b101: begin
            HEX7 = L; HEX6 = L; HEX5 = O;
            HEX1 = H; HEX0 = E;
        end

        // 110: LO---HEL
        3'b110: begin
            HEX7 = L; HEX6 = O;
            HEX2 = H; HEX1 = E; HEX0 = L;
        end

        // 111: O---HELL
        3'b111: begin
            HEX7 = O;
            HEX3 = H; HEX2 = E; HEX1 = L; HEX0 = L;
        end

    endcase
end

endmodule