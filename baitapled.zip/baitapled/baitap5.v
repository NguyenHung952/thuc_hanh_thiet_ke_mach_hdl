module baitap5(
    input  [17:0] SW,
    output [6:0] HEX0
);

wire [2:0] mux_out;

// MUX chọn kênh
mux4_1_3bit U0 (
    .in0(SW[2:0]),
    .in1(SW[5:3]),
    .in2(SW[8:6]),
    .in3(SW[11:9]),
    .sel(SW[17:16]),
    .out(mux_out)
);

// Decoder ra LED 7 đoạn
seg7_char U1 (
    .data(mux_out),
    .seg(HEX0)
);

endmodule