module baitap4(
    input  [9:0] SW,     // SW[3:0] = input, SW[4] = Enable
    output [6:0] HEX0,   // đơn vị
    output [6:0] HEX1    // chục
);

wire [3:0] value;
assign value = SW[3:0];

reg [3:0] tens;
reg [3:0] units;

// ===== TÁCH SỐ THẬP PHÂN =====
always @(*) begin
    if (value < 10) begin
        tens  = 0;
        units = value;
    end else begin
        tens  = 1;
        units = value - 10;
    end
end

// ===== GỌI DECODER =====
decoder7seg d0 (.A(units), .E(SW[4]), .SEG(HEX0));
decoder7seg d1 (.A(tens),  .E(SW[4]), .SEG(HEX1));

endmodule


//================ DECODER 0–9 =================//
module decoder7seg(
    input [3:0] A,
    input E,                 
    output reg [6:0] SEG
);

always @(*) begin
    if (E == 1'b1)
        SEG = 7'b1111111; // OFF
    else begin
        case(A)
            4'b0000: SEG = 7'b1000000; // 0
            4'b0001: SEG = 7'b1111001; // 1
            4'b0010: SEG = 7'b0100100; // 2
            4'b0011: SEG = 7'b0110000; // 3
            4'b0100: SEG = 7'b0011001; // 4
            4'b0101: SEG = 7'b0010010; // 5
            4'b0110: SEG = 7'b0000010; // 6
            4'b0111: SEG = 7'b1111000; // 7
            4'b1000: SEG = 7'b0000000; // 8
            4'b1001: SEG = 7'b0010000; // 9
            default: SEG = 7'b1111111;
        endcase
    end
end

endmodule