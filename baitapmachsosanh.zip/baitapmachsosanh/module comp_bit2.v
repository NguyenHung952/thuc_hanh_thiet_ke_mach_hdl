module comp_bit2(

input A2,
input B2,

output gt2,
output eq2,
output lt2

);

comp1bit U2(
.A(A2),
.B(B2),
.A_gt_B(gt2),
.A_eq_B(eq2),
.A_lt_B(lt2)
);

endmodule