module bai1(

input  [7:0] SW,
output [7:0] LEDR

);

wire A_gt_B;
wire A_eq_B;
wire A_lt_B;

comp1bit_struct U1(

.A(SW[3]),
.B(SW[4]),
.E(SW[5]),

.A_gt_B(A_gt_B),
.A_eq_B(A_eq_B),
.A_lt_B(A_lt_B)

);

assign LEDR[3] = A_gt_B;
assign LEDR[4] = A_eq_B;
assign LEDR[5] = A_lt_B;

endmodule
