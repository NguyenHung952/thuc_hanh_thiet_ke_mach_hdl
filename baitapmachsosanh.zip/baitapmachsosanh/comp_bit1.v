module comp_bit1(

input A1,
input B1,

output gt1,
output eq1,
output lt1

);

comp1bit U1(
.A(A1),
.B(B1),
.A_gt_B(gt1),
.A_eq_B(eq1),
.A_lt_B(lt1)
);

endmodule