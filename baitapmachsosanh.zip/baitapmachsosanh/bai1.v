module bai1(

input  [7:0] SW,
output [7:0] LEDR

);

wire nA, nB;
wire w1, w2;
wire eq_temp;

// đảo bit
not (nA, SW[3]);
not (nB, SW[4]);

// A > B
and (LEDR[3], SW[5], SW[3], nB);

// A < B
and (LEDR[5], SW[5], nA, SW[4]);

// A = B
and (w1, SW[3], SW[4]);
and (w2, nA, nB);
or  (eq_temp, w1, w2);
and (LEDR[4], eq_temp, SW[5]);

endmodule
