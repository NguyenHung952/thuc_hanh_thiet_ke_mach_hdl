module comp_bit3(

input A3,
input B3,

output gt3,
output eq3,
output lt3

);

comp1bit U3(
.A(A3),
.B(B3),
.A_gt_B(gt3),
.A_eq_B(eq3),
.A_lt_B(lt3)
);

endmodule