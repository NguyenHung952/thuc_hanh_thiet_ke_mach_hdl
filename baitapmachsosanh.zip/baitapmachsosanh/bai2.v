module bai2 (

input  [7:0] SW,
output [7:0] LEDR

);

wire A1, A0, B1, B0, E;

assign A1 = SW[4];
assign A0 = SW[3];
assign B1 = SW[6];
assign B0 = SW[5];
assign E  = SW[7];

assign LEDR[4] = (~E) & ((A1 & B1 | (~A1 & ~B1)) & (A0 & B0 | (~A0 & ~B0)));

assign LEDR[3] = (~E) & ((A1 & ~B1) | ((A1 & B1 | (~A1 & ~B1)) & (A0 & ~B0)));

assign LEDR[5] = (~E) & ((~A1 & B1) | ((A1 & B1 | (~A1 & ~B1)) & (~A0 & B0)));

assign LEDR[2:0] = 3'b000;
assign LEDR[7:6] = 2'b00;

endmodule