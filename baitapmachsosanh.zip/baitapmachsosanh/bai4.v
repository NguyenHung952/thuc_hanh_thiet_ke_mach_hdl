module Bt4(LEDR,SW);
input [12:0] SW;
output [5:1] LEDR;
reg [5:1] LEDR;
wire [4:0] A,B;
wire [2:0] S;

	assign A = SW[4:0];
	assign B = SW[9:5];
	assign S = SW[12:10];

always @(*)
begin
    case(S)
    3'b000: LEDR = A & B;
    3'b001: LEDR = A ^ B;
    3'b010: LEDR = A + 5'd3;
    3'b011: LEDR = A | B;
    3'b100: LEDR = A + B;
    3'b101: LEDR = A - B;
    3'b110: LEDR = ~B;
    3'b111: LEDR = A - 1'b1;

    endcase
end
endmodule