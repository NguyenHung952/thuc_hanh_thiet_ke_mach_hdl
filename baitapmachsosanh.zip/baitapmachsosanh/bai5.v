module comparator_ALU(

input [3:0] A,
input [3:0] B,

output reg [4:0] F

);

always @(*) begin

if(A > B)
    F = A + B;

else if(A == B)
    F = A & B;

else
    F = A ^ B;

end

endmodule
