module comp1bit(

input a,
input b,
input E,

output y1, // A < B
output y2, // A = B
output y3  // A > B

);

assign y1 = E & (~a & b);                 // A < B
assign y2 = E & ((a & b) | (~a & ~b));    // A = B
assign y3 = E & (a & ~b);                 // A > B

endmodule