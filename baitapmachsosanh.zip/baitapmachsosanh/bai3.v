module bai3(

input [7:0] SW,
output [7:0] LEDR

);

wire y1_3,y2_3,y3_3;
wire y1_2,y2_2,y3_2;
wire y1_1,y2_1,y3_1;
wire y1_0,y2_0,y3_0;

/* 
C3 so sánh bit cao nhất A3 B3
Enable lấy từ SW0
*/

comp1bit C3(
.a(SW[7]),
.b(SW[3]),
.E(SW[0]),
.y1(y1_3),
.y2(y2_3),
.y3(y3_3)
);

/*
C2 so sánh A2 B2
chỉ hoạt động khi bit trước bằng nhau
*/

comp1bit C2(
.a(SW[6]),
.b(SW[2]),
.E(y2_3),
.y1(y1_2),
.y2(y2_2),
.y3(y3_2)
);

/*
C1 so sánh A1 B1
*/

comp1bit C1(
.a(SW[5]),
.b(SW[1]),
.E(y2_2),
.y1(y1_1),
.y2(y2_1),
.y3(y3_1)
);

/*
C0 so sánh bit thấp nhất
*/

comp1bit C0(
.a(SW[4]),
.b(SW[0]),
.E(y2_1),
.y1(y1_0),
.y2(y2_0),
.y3(y3_0)
);

/* 
Tổng hợp kết quả cuối
*/

assign LEDR[0] = y3_3 | y3_2 | y3_1 | y3_0; // A > B
assign LEDR[1] = y2_0;                      // A = B
assign LEDR[2] = y1_3 | y1_2 | y1_1 | y1_0; // A < B

endmodule