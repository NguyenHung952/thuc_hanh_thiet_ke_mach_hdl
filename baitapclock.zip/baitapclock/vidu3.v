module vidu3 (CLOCK_50, SW, HEX5, HEX4);

    //================ INPUT - OUTPUT ================
    input CLOCK_50;
    input [0:0] SW;
    output [6:0] HEX5, HEX4;

    //================ INTERNAL SIGNAL ================
    reg [3:0] bcd1, bcd2;
    reg clock_1s = 1'b0;
    integer q;

    //================ CLOCK DIVIDER ==================
    always @(posedge CLOCK_50) begin
        if (q == 25_000_000) begin
            q <= 0;
            clock_1s <= ~clock_1s;
        end else begin
            q <= q + 1;
        end
    end

    //================ BCD COUNTER ====================
    always @(posedge clock_1s) begin
        if (SW[0] == 1'b1) begin
            bcd1 <= 4'b0000;
            bcd2 <= 4'b0000;
        end else begin
            bcd1 <= bcd1 + 1;

            if (bcd1 == 4'b1001) begin
                bcd1 <= 4'b0000;
                bcd2 <= bcd2 + 1;

                if (bcd2 == 4'b1001)
                    bcd2 <= 4'b0000;
            end
        end
    end

    //================ HEX DISPLAY ====================
    hex7seg h0 (bcd1, HEX4);
    hex7seg h1 (bcd2, HEX5);

endmodule