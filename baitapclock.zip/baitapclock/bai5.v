module bai5 (CLOCK_50, SW,
             HEX0,HEX1,HEX2,HEX3,HEX4,HEX5,HEX6,HEX7);

    input CLOCK_50;
    input [17:0] SW;
    output [6:0] HEX0,HEX1,HEX2,HEX3,HEX4,HEX5,HEX6,HEX7;

    wire clk_500ms;
    wire [4:0] state;

    clock_div #(12_500_000) u_clk (
        .CLOCK_50(CLOCK_50),
        .rst(SW[17]),
        .clk_out(clk_500ms)
    );

    counter_state u_cnt (
        .clk(clk_500ms),
        .rst(SW[17]),
        .state(state)
    );

    display_fpga u_disp (
        .state(state),
        .HEX0(HEX0), .HEX1(HEX1), .HEX2(HEX2), .HEX3(HEX3),
        .HEX4(HEX4), .HEX5(HEX5), .HEX6(HEX6), .HEX7(HEX7)
    );

endmodule


//================ COUNTER =================
module counter_state (clk, rst, state);

    input clk, rst;
    output reg [4:0] state;

    always @(posedge clk) begin
        if (rst) state <= 0;
        else state <= state + 1;
    end

endmodule


//================ DISPLAY =================
module display_fpga (state,
                     HEX0,HEX1,HEX2,HEX3,HEX4,HEX5,HEX6,HEX7);

    input [4:0] state;
    output reg [6:0] HEX0,HEX1,HEX2,HEX3,HEX4,HEX5,HEX6,HEX7;

    parameter F = 7'b0001110;
    parameter P = 7'b0001100;
    parameter G = 7'b0000010;
    parameter A = 7'b0001000;
    parameter DASH = 7'b0111111;
    parameter OFF  = 7'b1111111;

    always @(*) begin
        HEX0=OFF; HEX1=OFF; HEX2=OFF; HEX3=OFF;
        HEX4=OFF; HEX5=OFF; HEX6=OFF; HEX7=OFF;

        case(state)
            5'd0:  HEX7 = DASH;
            5'd1:  begin HEX7=A; HEX6=DASH; end
            5'd2:  begin HEX7=G; HEX6=A; HEX5=DASH; end
            5'd3:  begin HEX7=P; HEX6=G; HEX5=A; HEX4=DASH; end
            5'd4:  begin HEX7=F; HEX6=P; HEX5=G; HEX4=A; HEX3=DASH; end

            5'd5:  begin HEX7=DASH; HEX6=F; HEX5=P; HEX4=G; HEX3=A; HEX2=DASH; end

            5'd6:  begin HEX6=DASH; HEX5=F; HEX4=P; HEX3=G; HEX2=A; HEX1=DASH; end
            5'd7:  begin HEX5=DASH; HEX4=F; HEX3=P; HEX2=G; HEX1=A; HEX0=DASH; end

            5'd8:  begin HEX4=DASH; HEX3=F; HEX2=P; HEX1=G; HEX0=A; end
            5'd9:  begin HEX3=DASH; HEX2=F; HEX1=P; HEX0=G; end
            5'd10: begin HEX2=DASH; HEX1=F; HEX0=P; end
            5'd11: begin HEX1=DASH; HEX0=F; end
            5'd12: begin HEX0=DASH; end

            default: ;
        endcase
    end

endmodule