module bai3(CLOCK_50, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, SW);

input CLOCK_50;
input [0:0] SW;
output reg [6:0] HEX1, HEX2, HEX3, HEX4, HEX5, HEX6;

integer q;

always @(posedge CLOCK_50)
begin
    if(q == 400000000)
        q <= 0;
    else
        q <= q + 1;

    if(q < 300000000)
    begin
        if(SW[0] == 1'b1)
        begin
            HEX1 = 7'b1111111;
            HEX2 = 7'b1111111;
            HEX3 = 7'b1111111;
            HEX4 = 7'b1111111;
            HEX5 = 7'b1111111;
            HEX6 = 7'b1111111;
        end
        else
        begin
            // GOOGLE (dịch sang HEX1→HEX6)
            HEX1 = 7'b0000110; // E
            HEX2 = 7'b1000111; // L
            HEX3 = 7'b0000010; // G
            HEX4 = 7'b1000000; // O
            HEX5 = 7'b1000000; // O
            HEX6 = 7'b0000010; // G
        end
    end
    else
    begin
        HEX1 = 7'b1111111;
        HEX2 = 7'b1111111;
        HEX3 = 7'b1111111;
        HEX4 = 7'b1111111;
        HEX5 = 7'b1111111;
        HEX6 = 7'b1111111;
    end
end

endmodule