module bai4(CLOCK_50, SW, HEX4, HEX5);
    input CLOCK_50;
    input [0:0] SW;
    output [6:0] HEX4, HEX5;
    wire [3:0] dv, ch;
	 
    bcd24_0 u1(
        .CLOCK_50(CLOCK_50), 
        .rs(SW[0]), 
        .bcd0(dv), 
        .bcd1(ch)
    );

    bcd_7seg u2(.bcd(ch), .display(HEX5));
    bcd_7seg u3(.bcd(dv), .display(HEX4));
endmodule

module bcd24_0(CLOCK_50, rs, bcd0, bcd1);
    input CLOCK_50, rs;
    output reg [3:0] bcd0, bcd1;
    
    integer q = 0;

    always @(posedge CLOCK_50)
    begin
        if (rs == 1'b1) begin
            bcd0 <= 4'b0100;
            bcd1 <= 4'b0010;
            q <= 0;
        end
        else begin
            if (q >= 75000000) begin
                q <= 0;
                if (bcd1 == 0 && bcd0 == 0) begin
                    bcd0 <= 4'b0100; 
                    bcd1 <= 4'b0010;
                end
                else if (bcd0 == 0) begin
                    bcd0 <= 4'b1001; 
                    bcd1 <= bcd1 - 1'b1;
                end
                else begin
                    bcd0 <= bcd0 - 1'b1;
                end
            end
            else begin
                q <= q + 1;
            end
        end
    end
endmodule

module bcd_7seg(bcd, display);
    input [3:0] bcd;
    output reg [6:0] display;
    always @(*)
    begin
        case(bcd)
            4'b0000: display = 7'b1000000;
            4'b0001: display = 7'b1111001;
            4'b0010: display = 7'b0100100;
            4'b0011: display = 7'b0110000;
            4'b0100: display = 7'b0011001;
            4'b0101: display = 7'b0010010;
            4'b0110: display = 7'b0000010;
            4'b0111: display = 7'b1111000;
            4'b1000: display = 7'b0000000;
            4'b1001: display = 7'b0010000;
            default: display = 7'b1111111;
        endcase
    end
endmodule