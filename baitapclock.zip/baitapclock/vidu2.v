module vidu2 (CLOCK_50, LEDR, SW);
    input CLOCK_50;
    input [0:0] SW;
    output reg [3:0] LEDR;

    reg [25:0] q = 0;
    reg clock_1s = 1'b0;

    // ================= CHIA CLOCK =================
    always @(posedge CLOCK_50)
    begin
        if (q == 25000000)
        begin
            clock_1s <= ~clock_1s;
            q <= 0;
        end
        else
            q <= q + 1;
    end

    // ================= ĐIỀU KHIỂN LED =================
    always @(posedge clock_1s)
    begin
        if (SW[0] == 0)
            LEDR <= 4'b0000;
        else
            LEDR <= LEDR + 1;
    end
endmodule