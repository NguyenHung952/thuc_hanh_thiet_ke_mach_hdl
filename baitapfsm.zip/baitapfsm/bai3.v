module bai3(SW, KEY, LEDR);
parameter start = 3'b000;
parameter s1 = 3'b001;
parameter s10 = 3'b010;
parameter s101 = 3'b011;
parameter s1011 = 3'b100;
//1101
parameter s11 = 3'b101;
parameter s110 = 3'b110;
parameter s1101 = 3'b111;
// start: if(SW[1]) n_s = s1; else n_s = c_s;
//s10: if(SW[1]) n_s = _______; else n_s = _______;
input[3:0] SW;
input[2:2] KEY;
output reg[1:0]LEDR;
reg[2:0]c_s, n_s;
always @(*)
begin 
 case(c_s)
 start: if(SW[1]) n_s = s1;
    else n_s = c_s;
  s1: if(~SW[1]) n_s = s10;
   else n_s = s11;
  s10: if(SW[1]) n_s = s101;
   else n_s = start;
  s101: if(SW[1]) n_s = s1011;
   else n_s = s10;
  s1011: if(SW[1]) n_s = s11;
   else n_s = s110;
  //1101
  s11: if(~SW[1]) n_s = s110;
   else n_s = c_s;
  s110: if(SW[1]) n_s = s1101;
   else n_s = start;
  s1101: if(SW[1]) n_s = s1011;
   else n_s = s10;
  endcase
 end
always @(posedge KEY[2] or posedge SW[3])
begin 
 if(SW[3]) c_s <= start;
 else c_s <= n_s;
end
always@(*)
begin
LEDR[0] = 1'b0;
LEDR[1] = 1'b0;
if(c_s == s1011) LEDR[0] = 1'b1;
if(c_s == s1101) LEDR[1] = 1'b1; 
end
endmodule