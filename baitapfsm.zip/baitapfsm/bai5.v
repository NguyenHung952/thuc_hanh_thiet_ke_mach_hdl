module bai5 (SW,CLOCK_50,HEX0,HEX1,HEX2,HEX3);
input [1:1]SW;
input CLOCK_50;
output reg [6:0]HEX0,HEX1,HEX2,HEX3;
reg [2:0]current_state, next_state;
integer q;
reg clock_1s = 1'b0;
reg [3:0] sec = 0;

parameter s0 = 3'b000;
parameter s1 = 3'b001;
parameter s2 = 3'b010;
parameter s3 = 3'b011;
parameter s4 = 3'b100;
parameter s5 = 3'b101;
parameter s6 = 3'b110;

always @ (posedge CLOCK_50)
begin
 q=q+1;
 if (q == 25000000)
 begin
  clock_1s = ~clock_1s;
  q = 0;
 end
end

always @ (posedge clock_1s or posedge SW[1])
begin
 if (SW[1] == 1'b1) current_state <= s5;
 else     current_state <= next_state;
end 

always @ (*)
begin
 case (current_state)
  s0: next_state = s1;
  s1: next_state = s2;
  s2: next_state = s3;
  s3: next_state = s4;
  s4: next_state = s5;
  s5: next_state = s6;
  s6: next_state = s0;
  default: next_state = s0;
 endcase
end

always @ (*)
begin
 case (current_state)
  s0,s1,s2,s3,s4: 
  begin
   HEX3 = 7'b0100100;
   HEX2 = 7'b1000000;
   HEX1 = 7'b0100100;
   HEX0 = 7'b0011001;
  end
  
  s5,s6: 
  begin
   HEX3 = 7'b1111111;
   HEX2 = 7'b1111111;
   HEX1 = 7'b1111111;
   HEX0 = 7'b1111111;
  end
 endcase
end
endmodule
//bai5 2024 5s sáng 2s tắt