module vidu3 (SW, LEDR);

input [2:0] SW;
output reg [0:0] LEDR;

parameter start  = 3'b000;
parameter s1     = 3'b001;
parameter s10    = 3'b010;
parameter s101   = 3'b011;
parameter s1011  = 3'b100;

reg [2:0] current_state, next_state;

// Mạch chuyển trạng thái
always @(*)
begin
    case(current_state)

        start:
            if(SW[2]) next_state = s1;
            else      next_state = current_state;

        s1:
            if(~SW[2]) next_state = s10;
            else       next_state = current_state;

        s10:
            if(SW[2]) next_state = s101;
            else      next_state = start;

        s101:
            if(SW[2]) next_state = s1011;
            else      next_state = s10;

        s1011:
            if(SW[2]) next_state = s1;
            else      next_state = s10;

        default:
            next_state = start;

    endcase
end

// Thanh ghi trạng thái
always @(posedge SW[0] or posedge SW[1])
begin
    if(SW[1]) current_state <= start;
    else      current_state <= next_state;
end

// Ngõ ra
always @(*)
begin
    if(current_state == s1011)
        LEDR[0] = 1'b1;
    else
        LEDR[0] = 1'b0;
end

endmodule