//bt6
module bai6 (SW,KEY,LEDR,HEX0);
    input [2:1] SW;
	 input [1:1] KEY;
	 output reg [3:0] LEDR;
    output reg [6:0] HEX0;

    parameter start     = 4'b0000;
    parameter s0        = 4'b0001;
	 parameter s01 	   = 4'b0010;
	 parameter s010      = 4'b0011;
	 parameter s0100     = 4'b0100;
	 parameter s01000    = 4'b0101;
	 parameter s010000   = 4'b0110;
	 parameter s0100001  = 4'b0111;
	 parameter s01000011 = 4'b1000;
	 
    reg [3:0] current_state, next_state;


    // Mạch tổ hợp xác định trạng thái kế tiếp
     always @ (*) begin
        case (current_state)
            start: if (SW[2]) next_state = start;
                   else       next_state = s0;

            s0:    if (SW[2]) next_state = s01;
                   else       next_state = s0;

            s01:   if (SW[2]) next_state = start;
                   else       next_state = s010;

            s010:   if (SW[2]) next_state = s01;
                   else       next_state = s0100;

            s0100:  if (SW[2]) next_state = s01;
                   else       next_state = s01000;

            s01000: if (SW[2]) next_state = s01;
                   else       next_state = s010000;

            s010000: if (SW[2]) next_state = s0100001;
                   else       next_state = s0;
						 
				s0100001: if (SW[2]) next_state = s01000011;
                   else       next_state = s010;	
						 
				s01000011: if (SW[2]) next_state = start;
                   else       next_state = s0;	 
            default: next_state = start;
        endcase
    end

    // Mạch tuần tự cập nhật trạng thái (Sử dụng Reset tích cực cao)
    always @ (negedge KEY[1] or negedge SW[1]) begin
        if (~SW[1]) 
            current_state <= start;
        else 
            current_state <= next_state;
    end

    // Mạch tổ hợp giải mã hiển thị ra LED 7 đoạn (HEX0)
    always @ (*) begin
		  LEDR [3:0] <= current_state;
        if (current_state == s01000011)
				HEX0 = 7'b1000110;
			else
				HEX0 = 7'b1111111;
    end
endmodule