module bai4 (SW,CLOCK_50,HEX0);
 input [0:0]SW;
 input CLOCK_50;
 output reg [6:0]HEX0;
 parameter s0 = 3'b000;
 parameter s1 = 3'b001;
 parameter s2 = 3'b010;
 parameter s3 = 3'b011;
 parameter s = 3'b100;
 reg [2:0]current_state, next_state;
 integer q=0;
 reg clock_2s = 1'b0;

 
always@ (posedge CLOCK_50)
 begin
  q=q+1;
  if (q == 49999999)
  begin
   clock_2s = ~clock_2s;
   q = 0;
  end
 end
 
 
 
always@(*)
 begin
  case (current_state)
   s  : next_state = s0;
   s0 : next_state = s1;
   s1 : next_state = s2;
   s2 : next_state = s3;
   s3 : next_state = s0;
 
   default next_state = s0;
  endcase
 end

 always @ (posedge clock_2s or posedge SW[0])
 begin
  if (SW[0]) current_state <= s;
  else current_state <= next_state;
 end

always @ (*)
 begin
  case (current_state)
  s : HEX0 = 7'b1111111;
  s0: HEX0 = 7'b0001110;//F
  s1: HEX0 = 7'b0001100;//P
  s2: HEX0 = 7'b0000010;//G
  s3: HEX0 = 7'b0001000;//A
  endcase
 end
endmodule