module bai2 (SW,KEY,LEDR);
 input [2:0] SW; 
 input [2:2] KEY;
 output [1:1] LEDR; 
 FSM my_fsm (
  .ck(KEY[2]), 
  .rs(SW[1]), 
  .C(SW[0]), 
  .Y(LEDR[1])
 );
endmodule

module FSM(ck, rs, C, Y);
 input ck, rs, C;
 output reg [0:0] Y;
 parameter start = 3'b000;
 parameter s0    = 3'b001;
 parameter s01   = 3'b010;
 parameter s010  = 3'b011;
 parameter s0100 = 3'b100;
 
 reg [2:0] c_s, n_s;

 always @ (*) begin
  case(c_s)
   start: 
    if (C == 1'b0) n_s = s0;
    else           n_s = start;
   s0: 
    if (C == 1'b1) n_s = s01;
    else           n_s = s0;
   s01: 
    if (C == 1'b0) n_s = s010;
    else           n_s = start;
   s010: 
    if (C == 1'b0) n_s = s0100;
    else           n_s = s01; 
   s0100: 
    if (C == 1'b0) n_s = s0;
    else           n_s = s01;
   default:           n_s = start;
  endcase
 end

 always @ (negedge ck or negedge rs) begin
  if (rs == 1'b0) c_s <= start;
  else            c_s <= n_s;
 end
 always @ (*) begin
  if (c_s == s0100) Y = 1'b1;
  else              Y = 1'b0;
 end
endmodule