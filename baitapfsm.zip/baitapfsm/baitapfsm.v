begin 
 case(c_s)
	start:	if(SW[1])	n_s=s1;
		else	n_s=c_s;
	s1:	if(SW[1])	n_s=s10;
		else	n_s=s11;
	s10:	if(SW[1])	n_s=s101;
		else	n_s=start;
	s101:	if(SW[1])	n_s=s1011;
		else	n_s=s10;
	s1011:	if(SW[1])	n_s=s11;
		else	n_s=s110;
	s11:	if(SW[1])	n_s=s110;
		else	n_s=c_s;
	s110:	if(SW[1])	n_s=s1101;
		else	n_s=start;
	s1101: if(SW[1])	n_s=s1011;
		else	n_s=s10;
		
		
begin 
 case(c_s)
 start: if(SW[1]) n_s = s1;
    else n_s = c_s;
  s1: if(~SW[1]) n_s = s10;
   else n_s = s11;
  s10: if(SW[1]) n_s = s101;
   else n_s = start;
  s101: if(SW[1]) n_s = s1011;
   else n_s = s10;
  s1011: if(SW[1]) n_s = s11;
   else n_s = s110;
  //1101
  s11: if(~SW[1]) n_s = s110;
   else n_s = c_s;
  s110: if(SW[1]) n_s = s1101;
   else n_s = start;
  s1101: if(SW[1]) n_s = s1011;
   else n_s = s10;
  endcase