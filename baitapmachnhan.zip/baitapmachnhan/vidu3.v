// vd3
module vidu3 (SW, HEX7, HEX6, HEX5, HEX4, HEX3, HEX2, HEX1, HEX0);
    input [15:0] SW;
    output [0:6] HEX7, HEX6, HEX5, HEX4, HEX3, HEX2, HEX1, HEX0;

    wire [3:0] A, B;
    wire [7:0] P;
    wire [3:1] C_b1, C_b2, C_b3;
    wire [5:2] PP1;
    wire [6:3] PP2;

    assign A = SW[11:8];
    assign B = SW[3:0];
    assign P[0] = A[0] & B[0];

    // Hàng 1
    fa b1_a0 (A[1] & B[0], A[0] & B[1], 1'b0, P[1], C_b1[1]);
    fa b1_a1 (A[2] & B[0], A[1] & B[1], C_b1[1], PP1[2], C_b1[2]);
    fa b1_a2 (A[3] & B[0], A[2] & B[1], C_b1[2], PP1[3], C_b1[3]);
    fa b1_a3 (1'b0, A[3] & B[1], C_b1[3], PP1[4], PP1[5]);

    // Hàng 2
    fa b2_a0 (PP1[2], A[0] & B[2], 1'b0, P[2], C_b2[1]);
    fa b2_a1 (PP1[3], A[1] & B[2], C_b2[1], PP2[3], C_b2[2]);
    fa b2_a2 (PP1[4], A[2] & B[2], C_b2[2], PP2[4], C_b2[3]);
    fa b2_a3 (PP1[5], A[3] & B[2], C_b2[3], PP2[5], PP2[6]);

    // Hàng 3
    fa b3_a0 (PP2[3], A[0] & B[3], 1'b0, P[3], C_b3[1]);
    fa b3_a1 (PP2[4], A[1] & B[3], C_b3[1], P[4], C_b3[2]);
    fa b3_a2 (PP2[5], A[2] & B[3], C_b3[2], P[5], C_b3[3]);
    fa b3_a3 (PP2[6], A[3] & B[3], C_b3[3], P[6], P[7]);

    // LED hiển thị
    hex7seg h7 (4'h0, HEX7);
    hex7seg h6 (A, HEX6);
    hex7seg h5 (4'h0, HEX5);
    hex7seg h4 (B, HEX4);
    hex7seg h3 (4'h0, HEX3);
    hex7seg h2 (4'h0, HEX2);
    hex7seg h1 (P[7:4], HEX1);
    hex7seg h0 (P[3:0], HEX0);

endmodule

module fa (a, b, ci, s, co);
    input a, b, ci;
    output s, co;
    wire a_xor_b = a ^ b;
    assign s = a_xor_b ^ ci;
    assign co = (~a_xor_b & b) | (a_xor_b & ci);
endmodule

module hex7seg (hex, display);
    input [3:0] hex;
    output [0:6] display;
    reg [0:6] display;
    always @ (hex) begin
        case (hex)
            4'h0: display = 7'b0000001;
            4'h1: display = 7'b1001111;
            4'h2: display = 7'b0010010;
            4'h3: display = 7'b0000110;
            4'h4: display = 7'b1001100;
            4'h5: display = 7'b0100100;
            4'h6: display = 7'b0100000;
            4'h7: display = 7'b0001111;
            4'h8: display = 7'b0000000;
            4'h9: display = 7'b0000100;
            4'hA: display = 7'b0001000;
            4'hB: display = 7'b1100000;
            4'hC: display = 7'b0110001;
            4'hD: display = 7'b1000010;
            4'hE: display = 7'b0110000;
            4'hF: display = 7'b0111000;
            default: display = 7'b1111111;
        endcase
    end
endmodule