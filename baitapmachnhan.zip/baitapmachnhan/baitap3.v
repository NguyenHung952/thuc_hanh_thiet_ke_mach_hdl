//BT3
module baitap3(SW, LEDR);
    input [11:0] SW;    
    output [7:1] LEDR;   // đổi từ [6:0] -> [7:1]

    wire [5:0] a, b;
    wire [6:0] s;
    wire n1, n2, n3, n4, n5;

    assign a = SW[5:0];
    assign b = SW[11:6];

    assign LEDR[1] = s[0];
    assign LEDR[2] = s[1];
    assign LEDR[3] = s[2];
    assign LEDR[4] = s[3];
    assign LEDR[5] = s[4];
    assign LEDR[6] = s[5];
    assign LEDR[7] = s[6];

    // FA giữ nguyên
    fa f0 (n1, s[0], a[0], b[0], 1'b0);
    fa f1 (n2, s[1], a[1], b[1], n1);
    fa f2 (n3, s[2], a[2], b[2], n2);
    fa f3 (n4, s[3], a[3], b[3], n3);
    fa f4 (n5, s[4], a[4], b[4], n4);
    fa f5 (s[6], s[5], a[5], b[5], n5);

endmodule


// Full Adder giữ nguyên
module fa(co, s, a, b, ci);
    input a, b, ci;
    output co, s;
    wire n1, n2, n3, n4;

    xor (n1, a, b);
    xor (s, ci, n1);
    not (n2, n1);
    and (n3, n2, b);
    and (n4, ci, n1);
    or  (co, n3, n4);
endmodule