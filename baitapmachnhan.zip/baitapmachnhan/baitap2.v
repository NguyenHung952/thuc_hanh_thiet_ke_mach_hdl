module baitap2(SW,HEX3,HEX2,HEX1,HEX0);
input [7:0] SW;
output [6:0] HEX0, HEX1, HEX2, HEX3;
	wire [3:0] A, B;
	wire [7:0] P;
	wire n1, n2, n3, n4;
	assign A = SW[7:4];
	assign B = SW[3:0];
	assign P[7:5] = 3'b000;

	// module fa (a, b, ci, s, co);
	fa bit0 (A[0], B[0], 1'b0, P[0], n1);
	fa bit1 (A[1], B[1], n1, P[1], n2);
	fa bit2 (A[2], B[2], n2, P[2], n3);
	fa bit3 (A[3], B[3], n3, P[3], P[4]);
	
	//module hex7seg (hex, display);
	hex7seg(A[3:0], HEX3);
	hex7seg(B[3:0], HEX2);
	hex7seg(P[7:4], HEX1);
	hex7seg(P[3:0], HEX0);
	
	
endmodule

module hex7seg (hex, display);
	input [3:0] hex;
	output [0:6] display;
	reg [0:6] display;
	always @ (hex) begin
			case (hex)
				4'h0: display = 7'b1000000;
            4'h1: display = 7'b1111001;
            4'h2: display = 7'b0100100;
            4'h3: display = 7'b0110000;
            4'h4: display = 7'b0011001;
            4'h5: display = 7'b0010010;
            4'h6: display = 7'b0000010;
            4'h7: display = 7'b1111000;
            4'h8: display = 7'b0000000;
            4'h9: display = 7'b0010000;
            4'hA: display = 7'b0001000;
            4'hb: display = 7'b0000011;
            4'hC: display = 7'b1000110;
            4'hd: display = 7'b0100001;
            4'hE: display = 7'b0000110;
            4'hF: display = 7'b0001110;
            default: display = 7'b1111111;
			endcase
	end
endmodule


module fa (a, b, ci, s, co);
input a, b, ci;
output s, co;
	wire a_xor_b;
	assign a_xor_b = a ^ b;
	assign s = a_xor_b ^ ci;
	assign co = (~a_xor_b & b) | (a_xor_b & ci);
endmodule