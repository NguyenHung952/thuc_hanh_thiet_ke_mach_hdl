//bt5
module baitap5(SW,HEX7,HEX6,HEX5,HEX4,HEX3,HEX2,HEX1,HEX0);
 input [11:0] SW;
 output [6:0] HEX7,HEX6,HEX5,HEX4,HEX3,HEX2,HEX1,HEX0;
 wire [2:0] A, B, C, D;
 wire [5:0] P1, P2;
 wire [6:0] P3;
 
 assign A = SW[11:9];
 assign B = SW[8:6];
 assign C = SW[5:3];
 assign D = SW[2:0];
 
 bt4 A_B (A[2:0], B[2:0], P1);
 bt4 C_D (C[2:0], D[2:0], P2);
 
 bt3 (P1, P2, P3);
 
 //module hex7seg (hex, display);
 hex7seg ({1'b0, A[2:0]}, HEX7);
 hex7seg ({1'b0, B[2:0]}, HEX6);
 hex7seg ({1'b0, C[2:0]}, HEX5);
 hex7seg ({1'b0, D[2:0]}, HEX4);
 hex7seg (1'd0, HEX3);
 hex7seg (1'd0, HEX2);
 hex7seg ({1'b0, P3[6:4]}, HEX1);
 hex7seg (P3[3:0], HEX0);
endmodule
 
//BT4
module bt4(A, B, P);
input [2:0] A, B;
output [5:0] P;
 wire n1, n2, n3, n4, n5;
 wire s1, s2;
 assign P[0] = A[0] & B[0];

 // module fa (a, b, ci, s, co);
 fa b1_a0 (A[1] & B[0], A[0] & B[1], 1'b0, P[1], n1);
 fa b1_a1 (A[2] & B[0], A[1] & B[1], n1, s1, n2);
 fa b1_a2 (1'b0, A[2]&B[1], n2,  s2,  n3);
 
 fa b2_a0 (s1, A[0] & B[2], 1'b0, P[2], n4);
 fa b2_a1 (s2, A[1] & B[2], n4, P[3], n5);
 fa b2_a2 (n3, A[2] & B[2], n5, P[4], P[5]);

endmodule

//BT3
module bt3(a, b, P);
    input [5:0] a, b;    
    output [6:0] P;  
    wire n1, n2, n3, n4, n5;

    // fa (a, b, ci, s, co)
    fa f0 (a[0], b[0], 1'b0, P[0], n1);
    fa f1 (a[1], b[1], n1,   P[1], n2);
    fa f2 (a[2], b[2], n2,   P[2], n3);
    fa f3 (a[3], b[3], n3,   P[3], n4);
    fa f4 (a[4], b[4], n4,   P[4], n5);
    fa f5 (a[5], b[5], n5,   P[5], P[6]);
endmodule

// Module fa
module fa (a, b, ci, s, co);
input a, b, ci;
output s, co;
 wire a_xor_b;
 assign a_xor_b = a ^ b;
 assign s = a_xor_b ^ ci;
 assign co = (~a_xor_b & b) | (a_xor_b & ci);
endmodule

//Module giaima
module hex7seg (hex, display);
 input [3:0] hex;
 output [0:6] display;
 reg [0:6] display;
 always @ (hex) begin
   case (hex)
    4'h0: display = 7'b1000000;
            4'h1: display = 7'b1111001;
            4'h2: display = 7'b0100100;
            4'h3: display = 7'b0110000;
            4'h4: display = 7'b0011001;
            4'h5: display = 7'b0010010;
            4'h6: display = 7'b0000010;
            4'h7: display = 7'b1111000;
            4'h8: display = 7'b0000000;
            4'h9: display = 7'b0010000;
            4'hA: display = 7'b0001000;
            4'hb: display = 7'b0000011;
            4'hC: display = 7'b1000110;
            4'hd: display = 7'b0100001;
            4'hE: display = 7'b0000110;
            4'hF: display = 7'b0001110;
            default: display = 7'b1111111;
   endcase
 end
endmodule